import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  runTransaction,
  serverTimestamp,
  Unsubscribe,
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import type {
  Subscription,
  SubscriptionStatus,
  Member,
  SubscriptionWithMembers,
} from "@/lib/types"

const subsCol = () => collection(db, "subscriptions")
const membersCol = (subId: string) =>
  collection(db, "subscriptions", subId, "members")

// ─── Read ─────────────────────────────────────────────────────────────────────

/** Real-time listener — owner dashboard */
export function subscribeToSubscriptions(
  ownerId: string,
  onData: (subs: Subscription[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  // Simple single-field query — no composite index needed
  const q = query(subsCol(), where("ownerId", "==", ownerId))
  return onSnapshot(
    q,
    (snap) => {
      const subs = snap.docs
        .map((d) => ({ id: d.id, ...d.data() } as Subscription))
        .filter((s) => s.status !== "cancelled") // filter in memory
        .sort((a, b) => {
          // sort by createdAt descending in memory
          const aTime = (a.createdAt as any)?.seconds ?? 0
          const bTime = (b.createdAt as any)?.seconds ?? 0
          return bTime - aTime
        })
      onData(subs)
    },
    (err) => onError?.(err)
  )
}

/** Fetch a single subscription by ID */
export async function getSubscription(subId: string): Promise<Subscription | null> {
  const snap = await getDoc(doc(db, "subscriptions", subId))
  if (!snap.exists()) return null
  return { id: snap.id, ...snap.data() } as Subscription
}

/** Fetch all members of a subscription */
export async function getMembers(subId: string): Promise<Member[]> {
  const snap = await getDocs(membersCol(subId))
  return snap.docs.map((d) => ({ uid: d.id, ...d.data() } as Member))
}

/** Fetch subscription + members in parallel */
export async function getSubscriptionWithMembers(
  subId: string
): Promise<SubscriptionWithMembers | null> {
  const [sub, members] = await Promise.all([
    getSubscription(subId),
    getMembers(subId),
  ])
  if (!sub) return null
  return { ...sub, members }
}

/** Real-time listener for a single subscription's members */
export function subscribeToMembers(
  subId: string,
  onData: (members: Member[]) => void
): Unsubscribe {
  return onSnapshot(membersCol(subId), (snap) => {
    const members = snap.docs.map((d) => ({ uid: d.id, ...d.data() } as Member))
    onData(members)
  })
}

/** Get all subscriptions a member UID belongs to */
export async function getSubscriptionsForMember(
  uid: string
): Promise<Subscription[]> {
  // Use collectionGroup to find all member docs for this user
  const { collectionGroup } = await import("firebase/firestore")
  const q = query(collectionGroup(db, "members"), where("uid", "==", uid))
  const memberSnaps = await getDocs(q)
  const subIds = memberSnaps.docs.map((d) => d.ref.parent.parent!.id)
  const subs = await Promise.all(subIds.map((id) => getSubscription(id)))
  return subs.filter(Boolean) as Subscription[]
}

// ─── Create ───────────────────────────────────────────────────────────────────

export interface CreateSubscriptionInput {
  ownerId: string
  name: string
  totalCost: number
  dueDayOfMonth: number
}

export async function createSubscription(
  input: CreateSubscriptionInput
): Promise<string> {
  const ref = await addDoc(subsCol(), {
    ...input,
    status: "active" as SubscriptionStatus,
    createdAt: serverTimestamp(),
  })
  return ref.id
}

// ─── Members ─────────────────────────────────────────────────────────────────

export interface AddMemberInput {
  uid: string
  email: string
  displayName: string
}

export async function addMember(
  subId: string,
  input: AddMemberInput
): Promise<void> {
  await runTransaction(db, async (tx) => {
    const subRef = doc(db, "subscriptions", subId)
    const subSnap = await tx.get(subRef)
    if (!subSnap.exists()) throw new Error("Subscription not found")

    const sub = subSnap.data() as Subscription
    const membersSnap = await getDocs(membersCol(subId))
    const existingCount = membersSnap.docs.length

    if (membersSnap.docs.some((d) => d.id === input.uid)) {
      throw new Error("User is already a member")
    }

    const newCount = existingCount + 1
    const amountOwed = parseFloat((sub.totalCost / (newCount + 1)).toFixed(2))

    membersSnap.docs.forEach((d) => {
      tx.update(d.ref, { amountOwed })
    })

    const newMemberRef = doc(membersCol(subId), input.uid)
    tx.set(newMemberRef, {
      uid: input.uid,
      email: input.email,
      displayName: input.displayName,
      amountOwed,
      joinedAt: serverTimestamp(),
    })
  })
}

export async function removeMember(subId: string, uid: string): Promise<void> {
  await runTransaction(db, async (tx) => {
    const subRef = doc(db, "subscriptions", subId)
    const subSnap = await tx.get(subRef)
    if (!subSnap.exists()) throw new Error("Subscription not found")

    const sub = subSnap.data() as Subscription
    const membersSnap = await getDocs(membersCol(subId))
    const remaining = membersSnap.docs.filter((d) => d.id !== uid)

    const newCount = remaining.length
    const amountOwed =
      newCount === 0
        ? 0
        : parseFloat((sub.totalCost / (newCount + 1)).toFixed(2))

    remaining.forEach((d) => {
      tx.update(d.ref, { amountOwed })
    })

    tx.delete(doc(membersCol(subId), uid))
  })
}

// ─── Update ───────────────────────────────────────────────────────────────────

export async function updateSubscription(
  subId: string,
  updates: Partial<Pick<Subscription, "name" | "totalCost" | "dueDayOfMonth" | "status">>
): Promise<void> {
  await updateDoc(doc(db, "subscriptions", subId), updates)
}

export async function cancelSubscription(subId: string): Promise<void> {
  await updateDoc(doc(db, "subscriptions", subId), {
    status: "cancelled" as SubscriptionStatus,
  })
}
